var name,age,sex,height,weight,tel,mail;

name="姓名：";
document.write(name);
name="张凤宽";
document.write(name+"<br/>");

age="年龄：";
document.write(age);
age="18";
document.write(age+"<br/>");

sex="性别：";
document.write(sex);
sex="女";
document.write(sex+"<br/>");

height="身高：";
document.write(height);
height="165";
document.write(height+"<br/>");

weight="体重：";
document.write(weight);
weight="50";
document.write(weight+"<br/>");

tel="电话：";
document.write(tel);
tel="12345678901";
document.write(tel+"<br/>");

mail="邮箱：";
document.write(mail);
mail="1234567890@qq.com";
document.write(mail+"<br/>");
